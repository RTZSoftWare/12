# Rules
- Please respect the work of all developers who have made this possible
- Please pay attention to the license in this repository
- Do not in any form use the code in this repository for malware or data exfiltration.
- When using the logic or code used in this repository all developers should be accredited as mentioned in the credits.
- Jailbreaking with this is fun but be aware of the security risks of not updating your main device, anyone can use these bugs to spy or harm your device.
