/*
	CryptoGraphic Library for Modular JS
*/

include('libcrypto.md5');
include('libcrypto.sha');
include('libcrypto.sha1');