include('libdetect.device');
include('libdetect.sunspider3dcube');